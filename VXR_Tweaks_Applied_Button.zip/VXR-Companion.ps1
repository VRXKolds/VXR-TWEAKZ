# VXR Tweaks Windows Companion — limited, reversible user-level gaming preset
# No security changes, service killing, game-file edits, overclocking, or timer hacks.
# FPS and input-latency improvements are not guaranteed and vary by hardware/game.
$ErrorActionPreference = 'Stop'
$root = Join-Path $env:LOCALAPPDATA 'VXR-Tweaks'
$backupFile = Join-Path $root 'backup.json'
$gameBarPath = 'HKCU:\Software\Microsoft\GameBar'
$gameConfigPath = 'HKCU:\System\GameConfigStore'
$capturePath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'
New-Item -ItemType Directory -Path $root -Force | Out-Null

function Get-RegValueState([string]$Path,[string]$Name) {
  try {
    $key = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($key.GetValueNames() -contains $Name) { return @{ Exists=$true; Value=$key.GetValue($Name); Kind=[string]$key.GetValueKind($Name) } }
  } catch {}
  return @{ Exists=$false; Value=$null; Kind='DWord' }
}
function Get-ActivePowerPlan {
  $active = (powercfg /getactivescheme 2>$null | Out-String)
  return [regex]::Match($active,'[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}').Value
}
function Save-Backup {
  $backup = @{
    PowerPlan = (Get-ActivePowerPlan)
    GameBarAutoGameModeEnabled = (Get-RegValueState $gameBarPath 'AutoGameModeEnabled')
    GameBarAllowAutoGameMode = (Get-RegValueState $gameBarPath 'AllowAutoGameMode')
    GameDVR_Enabled = (Get-RegValueState $gameConfigPath 'GameDVR_Enabled')
    AppCaptureEnabled = (Get-RegValueState $capturePath 'AppCaptureEnabled')
    SavedAt = (Get-Date).ToString('o')
  }
  $backup | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $backupFile -Encoding UTF8
}
function Set-Dword([string]$Path,[string]$Name,[int]$Value) {
  New-Item -Path $Path -Force | Out-Null
  New-ItemProperty -LiteralPath $Path -Name $Name -PropertyType DWord -Value $Value -Force | Out-Null
  $actual = (Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop).$Name
  if ([int]$actual -ne $Value) { throw "Verification failed for $Name." }
}
function Get-HighPerformancePlan {
  $plans = (powercfg /list 2>$null | Out-String)
  $match = [regex]::Match($plans,'(?i)(8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c)')
  if ($match.Success) { return $match.Groups[1].Value }
  return ''
}
function Show-VXRStatus {
  Write-Host "Backup: $(if (Test-Path $backupFile) {'available'} else {'not created'})" -ForegroundColor Cyan
  Write-Host "Game Mode preference: AutoGameModeEnabled=$(Get-RegValueState $gameBarPath 'AutoGameModeEnabled' | ForEach-Object { if ($_.Exists) {$_.Value} else {'Windows default'} })"
  Write-Host "Background capture: GameDVR_Enabled=$(Get-RegValueState $gameConfigPath 'GameDVR_Enabled' | ForEach-Object { if ($_.Exists) {$_.Value} else {'Windows default'} }); AppCaptureEnabled=$(Get-RegValueState $capturePath 'AppCaptureEnabled' | ForEach-Object { if ($_.Exists) {$_.Value} else {'Windows default'} })"
  Write-Host "High Performance plan: $(if (Get-HighPerformancePlan) {'available'} else {'not listed on this PC'})"
}
function Apply-VXRPreset {
  if (-not (Test-Path $backupFile)) { Save-Backup }
  Set-Dword $gameBarPath 'AutoGameModeEnabled' 1
  Set-Dword $gameBarPath 'AllowAutoGameMode' 1
  Set-Dword $gameConfigPath 'GameDVR_Enabled' 0
  Set-Dword $capturePath 'AppCaptureEnabled' 0
  $high = Get-HighPerformancePlan
  if ($high) {
    powercfg /setactive $high 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Host 'Power plan could not be changed; other preferences were applied.' -ForegroundColor Yellow }
  } else {
    Write-Host 'High Performance plan is not listed; current plan left unchanged.' -ForegroundColor Yellow
  }
  Write-Host ''
  Write-Host 'VXR preset applied and registry values verified.' -ForegroundColor Green
  Write-Host 'Enabled Game Mode preferences and disabled background game capture for this Windows user.'
  Write-Host 'No services or security protections were disabled.'
  Write-Host 'Capture/recording features may be affected; use Restore to revert saved values.' -ForegroundColor Yellow
  Write-Host 'Retest the same game scene. FPS/input-latency gains are not guaranteed.' -ForegroundColor Yellow
  Show-VXRStatus
}
function Restore-Value([string]$Path,[string]$Name,$State) {
  if ($null -eq $State) { return }
  if ($State.Exists) {
    $kind=[string]$State.Kind
    if ($kind -notin @('DWord','QWord','String','ExpandString','Binary','MultiString')) { $kind='DWord' }
    New-Item -Path $Path -Force | Out-Null
    New-ItemProperty -LiteralPath $Path -Name $Name -PropertyType $kind -Value $State.Value -Force | Out-Null
  } else { Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue }
}
function Restore-VXRSettings {
  if (-not (Test-Path $backupFile)) { Write-Host 'No VXR backup found. No restore was performed.' -ForegroundColor Yellow; return }
  $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
  if ($backup.PowerPlan) { powercfg /setactive ([string]$backup.PowerPlan) 2>$null | Out-Null }
  Restore-Value $gameBarPath 'AutoGameModeEnabled' $backup.GameBarAutoGameModeEnabled
  Restore-Value $gameBarPath 'AllowAutoGameMode' $backup.GameBarAllowAutoGameMode
  Restore-Value $gameConfigPath 'GameDVR_Enabled' $backup.GameDVR_Enabled
  Restore-Value $capturePath 'AppCaptureEnabled' $backup.AppCaptureEnabled
  Remove-Item -LiteralPath $backupFile -Force
  Write-Host 'Saved VXR settings restored.' -ForegroundColor Green
  Show-VXRStatus
}

Write-Host ''
Write-Host 'VXR TWEAKS — WINDOWS COMPANION' -ForegroundColor Magenta
Write-Host 'This applies only a few reversible preferences. No FPS gains are guaranteed.' -ForegroundColor Gray
Write-Host '1. Apply VXR Competitive Preset'
Write-Host '2. Restore previous settings'
Write-Host '3. Check current status'
Write-Host '4. Exit'
$choice = Read-Host 'Choose an option'
try {
  switch ($choice) {
    '1' { Apply-VXRPreset }
    '2' { Restore-VXRSettings }
    '3' { Show-VXRStatus }
    default { Write-Host 'No changes made.' }
  }
} catch { Write-Host "Could not complete the preset: $($_.Exception.Message)" -ForegroundColor Red }
Write-Host ''
Read-Host 'Press Enter to close' | Out-Null
