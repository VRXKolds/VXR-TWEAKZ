import Stripe from 'stripe';

const headers = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': process.env.URL || '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export default async (request) => {
  if (request.method === 'OPTIONS') return new Response('', { status: 204, headers });
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed.' }, { status: 405, headers });
  if (!process.env.STRIPE_SECRET_KEY || !process.env.STRIPE_PRICE_ID || !process.env.URL) {
    return Response.json({ error: 'VXR Plus checkout is not configured yet.' }, { status: 503, headers });
  }
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const origin = process.env.URL.replace(/\/$/, '');
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      success_url: `${origin}/?session_id={CHECKOUT_SESSION_ID}#dashboard`,
      cancel_url: `${origin}/#vxr-plus`,
      allow_promotion_codes: true,
      billing_address_collection: 'auto',
      metadata: { product: 'VXR Plus', plan: 'monthly' },
    });
    return Response.json({ url: session.url }, { status: 200, headers });
  } catch (error) {
    console.error('VXR checkout session failed:', error.message);
    return Response.json({ error: 'Could not start checkout. Please try again later.' }, { status: 500, headers });
  }
};
