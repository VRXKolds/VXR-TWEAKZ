VXR TWEAKS — INDEPENDENT GAMING OPTIMIZATION HUB

CONTENTS
- index.html / styles.css / script.js: responsive VXR website and dashboard
- netlify/functions/: server-side Stripe checkout and subscription verification
- netlify.toml / package.json: Netlify deployment configuration and Stripe SDK
- VXR-Companion.ps1 / Run-VXR-Companion.bat: optional, limited Windows user-level preset

DESIGN / CONTENT
- Original VXR purple UI, direct individual tweak list, free items first, crowned Plus items below
- Game profiles include VALORANT, Fortnite, Minecraft, Call of Duty, Apex Legends, Rocket League and more
- VXR Points remain a separate browser-local reward system
- Inspired by common gaming optimization dashboard patterns, but this project does not copy EMTweaks' proprietary code, branding, or assets and is not affiliated with EMTweaks

MAKE VXR PLUS PAYMENTS LIVE (REQUIRED BEFORE LAUNCH)
This archive contains a Stripe Checkout integration, but payments cannot work until the site owner connects their own Stripe account and configures Netlify. Do not share secret keys in chat or put them in front-end files.

1. Create a Stripe account with the help of a parent/guardian if required for your age and location.
2. In Stripe, create a recurring product named “VXR Plus” priced at exactly $4.99 USD every month. Copy its Price ID (starts with price_).
3. Deploy this folder to Netlify. Keep the netlify/functions folder and netlify.toml in place.
4. In Netlify → Site configuration → Environment variables, add:
   - STRIPE_SECRET_KEY = your Stripe secret key (use test key first)
   - STRIPE_PRICE_ID = the recurring $4.99/month Price ID
   - URL = your full deployed site URL, e.g. https://your-site.netlify.app
5. Redeploy the site so the functions receive the variables.
6. Use Stripe test mode first. Test a successful subscription, a cancelled checkout, and an inactive/cancelled subscription. Verify Plus only unlocks when the server confirms an active subscription.
7. Before accepting real payments, finish Stripe account verification, configure customer support/refund and cancellation policies, add required terms/privacy disclosures, and thoroughly test production mode.

The create-checkout-session function creates a Stripe subscription Checkout Session on the server. The verify-subscription function checks the session and subscription status with Stripe; browser local storage by itself does not grant Plus. Stripe keys must stay in Netlify environment variables. This starter integration does not yet include a customer billing portal or automated webhook-driven account database. The current site login is a local demo, not secure server-side authentication. Do not describe it as a full account system.

DEPLOYMENT / PAYMENT LIMITS
- This is not yet a deployed website; the ZIP is the site source. Deploy it to Netlify to enable the included serverless payment functions.
- Until the Stripe environment variables are configured, checkout intentionally returns a setup message and no payment is collected.
- The $4.99 monthly Stripe price must be set by the site owner to match the displayed price.
- Cancelled or inactive subscriptions should not unlock Plus. The site re-verifies the Stripe subscription when it loads.
- Real account login, a billing portal, webhooks, and durable cross-device entitlements would be additional production hardening.

PERFORMANCE SAFETY
- The website provides guides; it does not automatically change all PC or console settings.
- The optional Windows companion changes a limited set of current-user Game Bar/capture preferences and may select the built-in High Performance power plan if available. It backs up prior values and offers restore. Review the PowerShell before running it.
- No FPS, ping, or input-latency improvement is guaranteed. Compare similar tests and revert changes that do not help.
- Keep Windows Security, Windows Update, audio, and essential driver services enabled. Avoid mass debloat scripts and unsupported “zero ping” claims.

CHECKOUT SETUP STATUS
Stripe integration code is included; live payment processing is not active until configured and tested by the site owner. Do not claim payments are live before a successful test checkout and entitlement check.
