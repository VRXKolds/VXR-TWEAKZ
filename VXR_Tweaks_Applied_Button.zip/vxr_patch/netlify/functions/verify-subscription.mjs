import Stripe from 'stripe';

const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };

export default async (request) => {
  if (request.method !== 'GET') return Response.json({ active: false, error: 'Method not allowed.' }, { status: 405, headers });
  if (!process.env.STRIPE_SECRET_KEY) return Response.json({ active: false, error: 'Payments are not configured.' }, { status: 503, headers });
  const sessionId = new URL(request.url).searchParams.get('session_id');
  if (!sessionId || !sessionId.startsWith('cs_')) return Response.json({ active: false }, { status: 400, headers });
  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(sessionId, { expand: ['subscription'] });
    const subscription = session.subscription;
    const active = session.mode === 'subscription' && session.status === 'complete' && !!subscription && typeof subscription !== 'string' && ['active', 'trialing'].includes(subscription.status);
    return Response.json({ active }, { status: 200, headers });
  } catch (error) {
    console.error('VXR subscription verification failed:', error.message);
    return Response.json({ active: false }, { status: 200, headers });
  }
};
